package coursework;
/**
 * A token superclass for all thieves.
 * 
 * @author Enzo Tobias 2117781
 *
 */
public abstract class Thief extends WalkingEntity {

}
