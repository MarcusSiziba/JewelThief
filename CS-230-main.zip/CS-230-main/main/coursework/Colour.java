package coursework;
/**
 * 
 * Colours viable to be used in tiles
 * 
 * @author Enzo Tobias 2117781
 */
public enum Colour {
	RED, GREEN, BLUE, YELLOW, CYAN, MAGENTA, VOID
}
