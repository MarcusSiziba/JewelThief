package coursework;
/**
 * Direction.
 * 
 * @author Enzo Tobias 2117781
 *
 */
public enum Direction {
	UP, RIGHT, DOWN, LEFT
}
